package example.demo.controller;

import example.demo.service.GameScoringService;
import example.demo.service.GameScoringService.GameRankingResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import java.util.stream.Collectors;

@RestController
public class SearchController {

    @Autowired
    private GameScoringService gameScoringService;
    
    private static final Logger logger = LoggerFactory.getLogger(SearchController.class);

    @GetMapping("/api/search")
    public Map<String, Object> search(@RequestParam(name = "keyword", required = false) String keyword) {
        logger.info("收到搜尋請求：keyword={}", keyword);
        
        Map<String, Object> response = new HashMap<>();
        response.put("keyword", keyword != null ? keyword : "");
        
        if (keyword == null || keyword.trim().isEmpty()) {
            response.put("results", Collections.emptyList());
            response.put("message", "請輸入搜尋關鍵字");
            return response;
        }

        try {
            Map<String, GameRankingResult> rankingResults = gameScoringService.searchAndRank(keyword);
            
            List<Map<String, Object>> formattedResults = rankingResults.entrySet().stream()
                    .map(entry -> {
                        String gameId = entry.getKey();
                        GameRankingResult result = entry.getValue();
                        
                        Map<String, Object> gameInfo = new HashMap<>();
                        gameInfo.put("gameId", gameId);
                        gameInfo.put("gameName", result.getTitle());
                        gameInfo.put("url", result.getLink());
                        gameInfo.put("score", Math.round(result.getScore() * 100.0) / 100.0);
                        
                        if (result.getNode() != null) {
                            gameInfo.put("isParent", result.getNode().isParent());
                            gameInfo.put("childCount", result.getNode().getChildren().size());
                            
                            List<Map<String, Object>> childPages = result.getNode().getChildren().stream()
                                    .map(child -> {
                                        Map<String, Object> childInfo = new HashMap<>();
                                        childInfo.put("title", child.getTitle());
                                        childInfo.put("url", child.getUrl());
                                        childInfo.put("score", Math.round(child.getScore() * 100.0) / 100.0);
                                        return childInfo;
                                    })
                                    .collect(Collectors.toList());
                            
                            gameInfo.put("childPages", childPages);
                        }
                        
                        return gameInfo;
                    })
                    .collect(Collectors.toList());
            
            response.put("results", formattedResults);
            response.put("totalGames", formattedResults.size());
            response.put("message", "搜尋成功");

            // ★★★ 新增邏輯：檢查最高分是否過低 (低於 25 分) ★★★
            if (!formattedResults.isEmpty()) {
                // 因為結果已經按分數排序，所以取第一個就是最高分
                Double topScore = (Double) formattedResults.get(0).get("score");
                if (topScore < 25.0) {
                    // 加入警告訊息
                    response.put("warning", "找不到高度相關的遊戲結果，以下為最接近的搜尋結果");
                }
            }
            
            logger.info("搜尋完成：找到 {} 個遊戲", formattedResults.size());
            
        } catch (Exception e) {
            logger.error("搜尋過程發生錯誤", e);
            response.put("results", Collections.emptyList());
            response.put("message", "搜尋失敗：" + e.getMessage());
        }
        
        return response;
    }
}