package example.demo.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.springframework.cache.annotation.Cacheable;

@Service
public class GoogleSearchService {

    @Value("${google.cse.apiKey}")
    private String apiKey;

    @Value("${google.cse.cx}")
    private String cx;

    private final RestTemplate restTemplate = new RestTemplate();

    public Map<String, String> search(String query) {
        Map<String, String> results = new LinkedHashMap<>();
        
        if (query == null || query.trim().isEmpty()) {
            return results;
        }

        // 回歸最單純的關鍵字：只加 " game" 幫助聚焦
        String searchTerm = query.trim() + " 遊戲";

        try {
            URI uri = UriComponentsBuilder.fromHttpUrl("https://www.googleapis.com/customsearch/v1")
                    .queryParam("key", apiKey)
                    .queryParam("cx", cx)
                    .queryParam("num", 10)
                    .queryParam("q", searchTerm)
                    .queryParam("gl", "tw")
                    .build()
                    .toUri();

            ResponseEntity<Map<String, Object>> response = restTemplate.exchange(
                uri, HttpMethod.GET, null, new ParameterizedTypeReference<Map<String, Object>>() {}
            );
            
            Map<String, Object> body = response.getBody();
            if (body != null && body.containsKey("items")) {
                List<?> items = (List<?>) body.get("items");
                for (Object itemObj : items) {
                    if (itemObj instanceof Map) {
                        Map<String, Object> item = (Map<String, Object>) itemObj;
                        String title = (String) item.get("title");
                        String link = (String) item.get("link");
                        if (title != null && link != null) {
                            results.put(title, link);
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Google API 連線失敗: " + e.getMessage());
        }
        return results;
    }
}