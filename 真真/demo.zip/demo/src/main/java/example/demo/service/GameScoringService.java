package example.demo.service;

import example.demo.service.Node;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class GameScoringService {

    private static final Logger logger = LoggerFactory.getLogger(GameScoringService.class);

    private static final Map<String, Double> GAME_FEATURE_KEYWORDS = Map.ofEntries(
        Map.entry("Steam", 1.5), Map.entry("RPG", 1.2), Map.entry("攻略", 1.2),
        Map.entry("下載", 1.0), Map.entry("官方", 1.0), Map.entry("評測", 0.8), 
        Map.entry("遊戲", 0.8), Map.entry("Game", 0.8), Map.entry("Simulator", 2.0),
        Map.entry("模擬", 1.5), Map.entry("Indie", 1.5), Map.entry("Gameplay", 1.5)
    );

    private static final Map<String, Double> PLATFORM_BONUS = Map.ofEntries(
        Map.entry("store.steampowered.com", 100.0),
        Map.entry("playstation.com", 80.0),
        Map.entry("nintendo.com", 80.0),
        Map.entry("xbox.com", 80.0),
        Map.entry("apps.apple.com", 60.0),
        Map.entry("play.google.com", 60.0),
        Map.entry("itch.io", 70.0),
        Map.entry("epicgames.com", 70.0),
        Map.entry("minecraft.net", 90.0),
        Map.entry("blizzard.com", 80.0),
        Map.entry("riotgames.com", 80.0)
    );

    private static final List<String> OFFICIAL_INDICATORS = List.of(
        "Official Site", "Official Website", "Homepage", "官方網站", "官網", "首頁"
    );

    private static final List<String> PENALTY_KEYWORDS = List.of(
        "購物車", "加入購物車", "Add to Cart", "運費", "Shipping", 
        "庫存", "In Stock", "TWD", "USD", "售價", "特價", "折價券",
        "拍賣", "露天", "蝦皮", "PChome", "MOMO"
    );

    @Autowired
    private GoogleSearchService googleSearchService;
    
    @Autowired
    private WebCrawlerService webCrawlerService;

    public Map<String, GameRankingResult> searchAndRank(String searchQuery) {
        Map<String, String> initialResults = googleSearchService.search(searchQuery);
        if (initialResults.isEmpty()) return new LinkedHashMap<>();
        
        List<Node> nodes = createNodesFromSearchResults(initialResults);
        
        String detectedEnglishName = extractEnglishNameFromNodes(nodes);
        if (detectedEnglishName != null) {
            logger.info("🔤 偵測到潛在英文名: {}", detectedEnglishName);
        }

        webCrawlerService.crawlPages(nodes);
        
        calculateScores(nodes, searchQuery, detectedEnglishName);
        
        List<Node> finalNodes = nodes.stream()
                .filter(node -> node.getScore() >= 11)
                .collect(Collectors.toList());

        if (finalNodes.isEmpty()) {
            logger.info("⚠️ 啟動救援機制...");
            finalNodes = nodes.stream()
                    .sorted((a, b) -> Double.compare(b.getScore(), a.getScore()))
                    .limit(3)
                    .collect(Collectors.toList());
        }

        Map<String, Node> gameGroups = identifyParentChildRelationships(finalNodes);
        return rankGames(gameGroups);
    }
    
    private String extractEnglishNameFromNodes(List<Node> nodes) {
        for (Node node : nodes) {
            String url = node.getUrl();
            String title = node.getTitle();
            if (url == null || title == null) continue;
            
            if (url.contains("store.steampowered.com") || url.contains("wikipedia.org")) {
                String englishPart = title.replaceAll("[^a-zA-Z0-9\\s:-]", " ").trim();
                
                englishPart = englishPart.replace("Steam", "")
                                         .replace("Wikipedia", "")
                                         .replace("Game", "")
                                         .replace("Official", "")
                                         .trim();
                
                String cleanName = englishPart.replaceAll("[^a-zA-Z0-9]", "").toLowerCase();
                
                if (cleanName.length() >= 4) {
                    return cleanName;
                }
            }
        }
        return null;
    }

    private void calculateScores(List<Node> nodes, String userQuery, String detectedEnglishName) {
        String cleanUserQuery = userQuery.toLowerCase().replaceAll("\\s+", "");

        for (Node node : nodes) {
            if (node.getContent() == null || node.getContent().isEmpty()) continue;
            
            double totalScore = 0.0;
            String fullContent = node.getTitle() + " " + node.getContent();
            String urlLower = node.getUrl().toLowerCase();
            String titleLower = node.getTitle().toLowerCase();

            int queryInTitle = countKeywordOccurrences(node.getTitle(), userQuery);
            int queryInContent = countKeywordOccurrences(fullContent, userQuery);
            totalScore += (queryInTitle * 10.0) + (queryInContent * 1.0);
            
            for (Map.Entry<String, Double> kw : GAME_FEATURE_KEYWORDS.entrySet()) {
                if (fullContent.contains(kw.getKey())) totalScore += kw.getValue();
            }

            for (Map.Entry<String, Double> entry : PLATFORM_BONUS.entrySet()) {
                if (urlLower.contains(entry.getKey())) totalScore += entry.getValue();
            }

            boolean domainMatch = false;
            
            if (urlLower.contains(cleanUserQuery)) domainMatch = true;
            
            else if (detectedEnglishName != null && urlLower.contains(detectedEnglishName)) {
                domainMatch = true;
                logger.info("🚀 跨語言網域命中! [{}]: {}", detectedEnglishName, node.getUrl());
            }

            if (domainMatch) {
                totalScore += 40.0;
                if (urlLower.endsWith(".com/") || urlLower.endsWith(".net/") || urlLower.endsWith(".org/")) {
                    totalScore += 10.0;
                }
            }

            for (String indicator : OFFICIAL_INDICATORS) {
                if (titleLower.contains(indicator.toLowerCase())) {
                    totalScore += 30.0;
                    break; 
                }
            }

            int penaltyCount = 0;
            for (String penaltyWord : PENALTY_KEYWORDS) {
                if (fullContent.contains(penaltyWord)) penaltyCount++;
            }
            if (penaltyCount > 0) {
                totalScore -= Math.min(penaltyCount * 5.0, 50.0);
            }

            node.setScore(totalScore);
        }
    }

    private List<Node> createNodesFromSearchResults(Map<String, String> r) {
        List<Node> l = new ArrayList<>();
        if (r != null) for (Map.Entry<String, String> e : r.entrySet()) l.add(new Node(e.getValue(), e.getKey()));
        return l;
    }
    private int countKeywordOccurrences(String t, String k) {
        if (t == null || k == null || k.isEmpty()) return 0;
        return t.split(Pattern.quote(k), -1).length - 1;
    }
    private Map<String, Node> identifyParentChildRelationships(List<Node> n) {
        Map<String, Node> m = new HashMap<>();
        for (Node node : n) { node.setParent(true); m.put(node.getTitle(), node); }
        return m;
    }
    private Map<String, GameRankingResult> rankGames(Map<String, Node> g) {
        return g.entrySet().stream()
            .sorted((a, b) -> Double.compare(b.getValue().getScore(), a.getValue().getScore()))
            .collect(Collectors.toMap(Map.Entry::getKey, e -> new GameRankingResult(e.getValue().getUrl(), e.getValue().getScore(), e.getValue().getTitle(), e.getValue()), (e1, e2) -> e1, LinkedHashMap::new));
    }

    public static class GameRankingResult {
        public final String link; 
        public final double score; 
        public final String title; 
        public final Node node;
        public GameRankingResult(String l, double s, String t, Node n) { link=l; score=s; title=t; node=n; }
        public String getLink() { return link; }
        public double getScore() { return score; }
        public String getTitle() { return title; }
        public Node getNode() { return node; }
    }
}