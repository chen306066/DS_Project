package example.demo.service;

import java.util.ArrayList;
import java.util.List;

public class Node {
    private String gameId;           
    private String url;              
    private String title;            
    private String content;          
    private String metaDescription;
    private String metaKeywords;
    private List<String> headings;
    
    private double score;           
    private boolean isParent;       
    private List<Node> children;     
    
    private int titleMatchCount;     
    private int contentMatchCount;  
    private String schemaType; 

    public String getSchemaType() { return schemaType; }
    
    public void setSchemaType(String schemaType) { this.schemaType = schemaType; }
    
    public Node(String url, String title) {
        this.url = url;
        this.title = title;
        this.children = new ArrayList<>();
        this.headings = new ArrayList<>();
        this.isParent = false;
        this.score = 0.0;
    }
    
    
    public double calculateTotalScore() {
        double totalScore = this.score;
        
        if (isParent && !children.isEmpty()) {
            totalScore += children.stream()
                    .mapToDouble(Node::getScore)
                    .sum();
        }
        
        return totalScore;
    }
    
   
    public void addChild(Node child) {
        this.children.add(child);
    }
    
   
    public void calculateScore(double keywordWeight) {
        this.score = (titleMatchCount * 1.5 + contentMatchCount * 1.0) * keywordWeight;
    }
    
    public String getGameId() {
        return gameId;
    }
    
    public void setGameId(String gameId) {
        this.gameId = gameId;
    }
    
    public String getUrl() {
        return url;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getContent() {
        return content;
    }
    
    public void setContent(String content) {
        this.content = content;
    }
    
    public String getMetaDescription() {
        return metaDescription;
    }
    
    public void setMetaDescription(String metaDescription) {
        this.metaDescription = metaDescription;
    }
    
    public String getMetaKeywords() {
        return metaKeywords;
    }
    
    public void setMetaKeywords(String metaKeywords) {
        this.metaKeywords = metaKeywords;
    }
    
    public List<String> getHeadings() {
        return headings;
    }
    
    public void setHeadings(List<String> headings) {
        this.headings = headings;
    }
    
    public double getScore() {
        return score;
    }
    
    public void setScore(double score) {
        this.score = score;
    }
    
    public boolean isParent() {
        return isParent;
    }
    
    public void setParent(boolean parent) {
        isParent = parent;
    }
    
    public List<Node> getChildren() {
        return children;
    }
    
    public int getTitleMatchCount() {
        return titleMatchCount;
    }
    
    public void setTitleMatchCount(int titleMatchCount) {
        this.titleMatchCount = titleMatchCount;
    }
    
    public int getContentMatchCount() {
        return contentMatchCount;
    }
    
    public void setContentMatchCount(int contentMatchCount) {
        this.contentMatchCount = contentMatchCount;
    }
    
    @Override
    public String toString() {
        return "Node{" +
                "gameId='" + gameId + '\'' +
                ", title='" + title + '\'' +
                ", url='" + url + '\'' +
                ", score=" + score +
                ", isParent=" + isParent +
                ", childrenCount=" + children.size() +
                '}';
    }
}
