package example.demo.service;

import example.demo.service.Node;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class WebCrawlerService {
    
    private static final Logger logger = LoggerFactory.getLogger(WebCrawlerService.class);
    private static final String USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36";
    
    public boolean crawlPage(Node node) {
        String urlLower = node.getUrl().toLowerCase();
        if (urlLower.endsWith(".pdf") || urlLower.endsWith(".xml") || urlLower.endsWith(".zip")) return false;

        try {
            Document doc = Jsoup.connect(node.getUrl())
                    .userAgent(USER_AGENT)
                    .timeout(5000) 
                    .get();
            
            extractMetaTags(doc, node);
            extractHeadings(doc, node);
            extractTextContent(doc, node);
            
            extractSchemaData(doc, node);
            
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void extractSchemaData(Document doc, Node node) {
        Elements schemas = doc.select("script[type=application/ld+json]");
        for (Element schema : schemas) {
            String json = schema.data();
            if (json.contains("\"VideoGame\"") || 
                json.contains("\"SoftwareApplication\"") || 
                json.contains("\"Game\"") ||
                json.contains("store.steampowered.com")) { 
                node.setSchemaType("Game"); 
                break;
            }
        }
    }
    
    private void extractMetaTags(Document doc, Node node) { }
    private void extractHeadings(Document doc, Node node) { }
    private void extractTextContent(Document doc, Node node) { 
        doc.select("script, style, nav, footer, header").remove();
        node.setContent(doc.body().text());
    }
    public List<Node> crawlPages(List<Node> nodes) {
        return nodes.stream().parallel().peek(this::crawlPage).collect(Collectors.toList());
    }
}