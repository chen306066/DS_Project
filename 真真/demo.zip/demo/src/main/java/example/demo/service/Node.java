package example.demo.service;

import java.util.ArrayList;
import java.util.List;

/**
 * Node 代表一個網頁節點
 * 父 Node：遊戲的主要頁面（官網、Steam 頁等）
 * 子 Node：相關的衍生頁面（評測'、攻略、討論等）
 */
public class Node {
    private String gameId;           // 遊戲唯一識別碼（從標題提取）
    private String url;              // 頁面 URL
    private String title;            // 頁面標題
    private String content;          // 抓取的內容（純文字）
    private String metaDescription;  // Meta description
    private String metaKeywords;     // Meta keywords
    private List<String> headings;   // H1, H2 標題列表
    
    private double score;            // 該頁面的分數
    private boolean isParent;        // 是否為父頁
    private List<Node> children;     // 子頁列表
    
    // 計分相關欄位
    private int titleMatchCount;     // 標題中的關鍵字匹配次數
    private int contentMatchCount;   // 內容中的關鍵字匹配次數
    // 在 Node.java 中新增
    private String schemaType; 

    public String getSchemaType() { return schemaType; }
    
    public void setSchemaType(String schemaType) { this.schemaType = schemaType; }
    
    public Node(String url, String title) {
        this.url = url;
        this.title = title;
        this.children = new ArrayList<>();
        this.headings = new ArrayList<>();
        this.isParent = false;
        this.score = 0.0;
    }
    
    /**
     * 計算總分數（包含所有子頁）
     * 公式：父頁總分 = 父頁自身分數 + Σ(子頁分數)
     */
    public double calculateTotalScore() {
        double totalScore = this.score;
        
        if (isParent && !children.isEmpty()) {
            totalScore += children.stream()
                    .mapToDouble(Node::getScore)
                    .sum();
        }
        
        return totalScore;
    }
    
    /**
     * 添加子頁
     */
    public void addChild(Node child) {
        this.children.add(child);
    }
    
    /**
     * 計算該頁面的分數
     * 公式：score = (標題匹配次數 * 1.5 + 內容匹配次數 * 1.0) * 關鍵字權重
     */
    public void calculateScore(double keywordWeight) {
        this.score = (titleMatchCount * 1.5 + contentMatchCount * 1.0) * keywordWeight;
    }
    
    // Getters and Setters
    public String getGameId() {
        return gameId;
    }
    
    public void setGameId(String gameId) {
        this.gameId = gameId;
    }
    
    public String getUrl() {
        return url;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getContent() {
        return content;
    }
    
    public void setContent(String content) {
        this.content = content;
    }
    
    public String getMetaDescription() {
        return metaDescription;
    }
    
    public void setMetaDescription(String metaDescription) {
        this.metaDescription = metaDescription;
    }
    
    public String getMetaKeywords() {
        return metaKeywords;
    }
    
    public void setMetaKeywords(String metaKeywords) {
        this.metaKeywords = metaKeywords;
    }
    
    public List<String> getHeadings() {
        return headings;
    }
    
    public void setHeadings(List<String> headings) {
        this.headings = headings;
    }
    
    public double getScore() {
        return score;
    }
    
    public void setScore(double score) {
        this.score = score;
    }
    
    public boolean isParent() {
        return isParent;
    }
    
    public void setParent(boolean parent) {
        isParent = parent;
    }
    
    public List<Node> getChildren() {
        return children;
    }
    
    public int getTitleMatchCount() {
        return titleMatchCount;
    }
    
    public void setTitleMatchCount(int titleMatchCount) {
        this.titleMatchCount = titleMatchCount;
    }
    
    public int getContentMatchCount() {
        return contentMatchCount;
    }
    
    public void setContentMatchCount(int contentMatchCount) {
        this.contentMatchCount = contentMatchCount;
    }
    
    @Override
    public String toString() {
        return "Node{" +
                "gameId='" + gameId + '\'' +
                ", title='" + title + '\'' +
                ", url='" + url + '\'' +
                ", score=" + score +
                ", isParent=" + isParent +
                ", childrenCount=" + children.size() +
                '}';
    }
}
