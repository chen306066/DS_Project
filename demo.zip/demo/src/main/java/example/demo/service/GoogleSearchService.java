package example.demo.service;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class GoogleSearchService {

    // 從 application.properties 讀取設定值
    @Value("${google.cse.apiKey}")
    private String apiKey;

    @Value("${google.cse.cx}")
    private String cx;

    private final RestTemplate restTemplate = new RestTemplate();

    /**
     * 呼叫 Google Custom Search API 進行搜尋
     * @param query 使用者輸入的搜尋關鍵字
     * @return 包含標題(String)和連結(String)的有序 Map
     */
    public Map<String, String> search(String query) {
        // 使用 LinkedHashMap 保持結果的順序
        Map<String, String> results = new LinkedHashMap<>();
        
        if (query == null || query.trim().isEmpty()) {
            return results;
        }

        try {
            // 1. URL 編碼查詢字串，以正確處理中文或其他特殊字元
            String q = URLEncoder.encode(query, StandardCharsets.UTF_8.name());
            
            // 2. 構建 API URL
            // 參考提示 4 的結構，並使用 UriComponentsBuilder 確保 URL 正確性
            String url = UriComponentsBuilder.fromHttpUrl("https://www.googleapis.com/customsearch/v1")
                    .queryParam("key", apiKey)
                    .queryParam("cx", cx)
                    .queryParam("num", 10) // 每次返回 10 個結果
                    .queryParam("q", q)
                    .toUriString();

            // 3. 執行 GET 請求並接收 Map<String, Object> 格式的 JSON 響應
            // 警告: 由於泛型擦除，需要進行類型轉換
            Map<String, Object> body = restTemplate.getForObject(
                url, (Class<Map<String, Object>>) (Class<?>) Map.class
            );
            
            if (body == null) {
                return results;
            }
            
            // 4. 解析 JSON 響應
            // 獲取 "items" 陣列 (即搜尋結果列表)
            Object itemsObj = body.get("items");
            if (itemsObj instanceof List) {
                List<?> items = (List<?>) itemsObj;
                for (Object itemObj : items) {
                    if (itemObj instanceof Map) {
                        Map<String, Object> item = (Map<String, Object>) itemObj;
                        
                        // 提取標題和連結
                        String title = (String) item.get("title");
                        String link = (String) item.get("link");
                        
                        if (title != null && !title.isEmpty() && link != null && !link.isEmpty()) {
                            results.put(title, link);
                        }
                    }
                }
            }
        } catch (Exception e) {
            // 處理 API 呼叫失敗 (例如：API Key 或 CX 錯誤，或每日配額用盡)
            System.err.println("Error calling Google CSE API for query [" + query + "]: " + e.getMessage());
            // 在實際應用中，您可以記錄錯誤並返回空結果
        }

        return results;
    }
}
