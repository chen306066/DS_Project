package example.demo.controller;

import example.demo.service.Node;
import example.demo.service.GameScoringService;
import example.demo.service.GameScoringService.GameRankingResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;
import java.util.stream.Collectors;

@RestController
public class SearchController {

    @Autowired
    private GameScoringService gameScoringService;
    
    private static final Logger logger = LoggerFactory.getLogger(SearchController.class);

    /**
     * 處理 /api/search 請求
     * @param keyword 使用者輸入的關鍵字
     * @return JSON 格式的遊戲排名結果
     */
    @GetMapping("/api/search")
    public Map<String, Object> search(@RequestParam(name = "keyword", required = false) String keyword) {
        logger.info("收到搜尋請求：keyword={}", keyword);
        
        Map<String, Object> response = new HashMap<>();
        response.put("keyword", keyword != null ? keyword : "");
        
        // 處理空關鍵字
        if (keyword == null || keyword.trim().isEmpty()) {
            response.put("results", Collections.emptyList());
            response.put("message", "請輸入搜尋關鍵字");
            return response;
        }

        try {
            // 呼叫計分服務進行搜尋與排名
            Map<String, GameRankingResult> rankingResults = gameScoringService.searchAndRank(keyword);
            
            // 轉換為前端友善的格式
            List<Map<String, Object>> formattedResults = rankingResults.entrySet().stream()
                    .map(entry -> {
                        String gameId = entry.getKey();
                        GameRankingResult result = entry.getValue();
                        
                        Map<String, Object> gameInfo = new HashMap<>();
                        gameInfo.put("gameId", gameId);
                        gameInfo.put("gameName", result.getTitle());
                        gameInfo.put("url", result.getLink());
                        gameInfo.put("score", Math.round(result.getScore() * 100.0) / 100.0); // 保留兩位小數
                        
                        // 加入父子頁資訊
                        if (result.getNode() != null) {
                            gameInfo.put("isParent", result.getNode().isParent());
                            gameInfo.put("childCount", result.getNode().getChildren().size());
                            
                            // 子頁詳情
                            List<Map<String, Object>> childPages = result.getNode().getChildren().stream()
                                    .map(child -> {
                                        Map<String, Object> childInfo = new HashMap<>();
                                        childInfo.put("title", child.getTitle());
                                        childInfo.put("url", child.getUrl());
                                        childInfo.put("score", Math.round(child.getScore() * 100.0) / 100.0);
                                        return childInfo;
                                    })
                                    .collect(Collectors.toList());
                            
                            gameInfo.put("childPages", childPages);
                        }
                        
                        return gameInfo;
                    })
                    .collect(Collectors.toList());
            
            response.put("results", formattedResults);
            response.put("totalGames", formattedResults.size());
            response.put("message", "搜尋成功");
            
            logger.info("搜尋完成：找到 {} 個遊戲", formattedResults.size());
            
        } catch (Exception e) {
            logger.error("搜尋過程發生錯誤", e);
            response.put("results", Collections.emptyList());
            response.put("message", "搜尋失敗：" + e.getMessage());
        }
        
        return response;
    }
}