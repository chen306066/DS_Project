package example.demo.controller;

import example.demo.service.GoogleSearchService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
public class SearchController {

    @Autowired
    private GoogleSearchService googleSearchService;
    
    private static final Logger logger = LoggerFactory.getLogger(SearchController.class);

    /**
     * 處理 /api/search 請求，返回 JSON 格式的搜尋結果
     * @param keyword 從前端傳來的關鍵字
     * @return JSON 格式的搜尋結果
     */
    @GetMapping("/api/search")
    public Map<String, Object> search(@RequestParam(name = "keyword", required = false) String keyword) {
        logger.info("Handling /api/search request with keyword: {}", keyword);
        
        Map<String, Object> response = new HashMap<>();
        
        // 處理空關鍵字的情況
        if (keyword == null || keyword.trim().isEmpty()) {
            response.put("keyword", "");
            response.put("results", new HashMap<String, String>());
            return response;
        }

        // 呼叫服務進行搜尋
        Map<String, String> searchResults = googleSearchService.search(keyword);
        
        // 將關鍵字和結果放入響應
        response.put("keyword", keyword);
        response.put("results", searchResults);
        
        return response;
    }
}