package example.demo.service;

import example.demo.service.Node;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Service
public class GameScoringService {

    private static final Logger logger = LoggerFactory.getLogger(GameScoringService.class);

    // 1. 遊戲特徵 (加分用) - 使用 Map.ofEntries 修復報錯
    private static final Map<String, Double> GAME_FEATURE_KEYWORDS = Map.ofEntries(
        Map.entry("Steam", 1.5), Map.entry("RPG", 1.2), Map.entry("攻略", 1.2),
        Map.entry("下載", 1.0), Map.entry("官方", 1.0), Map.entry("評測", 0.8), 
        Map.entry("遊戲", 0.8), Map.entry("Game", 0.8), Map.entry("Simulator", 2.0), 
        Map.entry("模擬", 1.5), Map.entry("Indie", 1.5), Map.entry("Gameplay", 1.5)
    );

    // 2. 知名遊戲平台 (大加分，讓 Steam 排第一)
    private static final Map<String, Double> PLATFORM_BONUS = Map.ofEntries(
        Map.entry("store.steampowered.com", 100.0),
        Map.entry("playstation.com", 80.0),
        Map.entry("nintendo.com", 80.0),
        Map.entry("xbox.com", 80.0),
        Map.entry("apps.apple.com", 60.0),
        Map.entry("play.google.com", 60.0),
        Map.entry("itch.io", 70.0),
        Map.entry("epicgames.com", 70.0),
        Map.entry("bandainamcoent", 60.0),
        Map.entry("ubisoft.com", 60.0),
        Map.entry("ea.com", 60.0),
        Map.entry("blizzard.com", 60.0)
    );

    // 3. 電商與雜訊特徵 (扣分用) - 這裡決定購物頁面會被扣分
    private static final List<String> PENALTY_KEYWORDS = List.of(
        "購物車", "加入購物車", "Add to Cart", "運費", "Shipping", 
        "庫存", "In Stock", "TWD", "USD", "售價", "特價", "折價券",
        "拍賣", "露天", "蝦皮", "PChome", "MOMO"
    );

    @Autowired
    private GoogleSearchService googleSearchService;
    
    @Autowired
    private WebCrawlerService webCrawlerService;

    public Map<String, GameRankingResult> searchAndRank(String searchQuery) {
        // 1. 搜尋
        Map<String, String> initialResults = googleSearchService.search(searchQuery);
        if (initialResults.isEmpty()) return new LinkedHashMap<>();
        
        // 2. 建立節點與爬取
        List<Node> nodes = createNodesFromSearchResults(initialResults);
        webCrawlerService.crawlPages(nodes);
        
        // 3. 計算分數
        calculateScores(nodes, searchQuery);
        
        // 4. 排序與回傳
        Map<String, Node> gameGroups = identifyParentChildRelationships(nodes);
        return rankGames(gameGroups);
    }
    
    private void calculateScores(List<Node> nodes, String userQuery) {
        for (Node node : nodes) {
            // 防呆：搜「龍」不會當機
            if (node.getContent() == null || node.getContent().isEmpty()) continue;
            if (node.getTitle() == null) continue;
            
            double totalScore = 0.0;
            String fullContent = buildFullSearchableContent(node);
            String urlLower = node.getUrl().toLowerCase();

            // A. 基礎分數 (關鍵字命中)
            int userQueryInTitle = countKeywordOccurrences(node.getTitle(), userQuery);
            int userQueryInContent = countKeywordOccurrences(fullContent, userQuery);
            totalScore += (userQueryInTitle * 10.0) + (userQueryInContent * 1.0);
            
            // B. 遊戲特徵加分
            double featureScore = 0.0;
            for (Map.Entry<String, Double> keyword : GAME_FEATURE_KEYWORDS.entrySet()) {
                int count = countKeywordOccurrences(fullContent, keyword.getKey());
                if (count > 0) featureScore += count * keyword.getValue();
            }
            totalScore += featureScore * 0.5;

            // C. 平台權重加分 (Steam +100)
            for (Map.Entry<String, Double> entry : PLATFORM_BONUS.entrySet()) {
                if (urlLower.contains(entry.getKey())) {
                    totalScore += entry.getValue();
                }
            }

            // D. 電商扣分 (PChome -50)
            // 只是扣分，沒有刪除 (continue)，所以購物頁面還會在，但排很後面
            int penaltyCount = 0;
            for (String penaltyWord : PENALTY_KEYWORDS) {
                if (fullContent.contains(penaltyWord) || node.getTitle().contains(penaltyWord)) {
                    penaltyCount++;
                }
            }
            if (penaltyCount > 0) {
                double penalty = Math.min(penaltyCount * 5.0, 50.0);
                totalScore -= penalty;
            }

            node.setScore(totalScore);
        }
    }

    // --- 輔助方法 ---
    private List<Node> createNodesFromSearchResults(Map<String, String> r) {
        List<Node> l = new ArrayList<>();
        if (r != null) {
            for (Map.Entry<String, String> e : r.entrySet()) l.add(new Node(e.getValue(), e.getKey()));
        }
        return l;
    }
    private int countKeywordOccurrences(String t, String k) {
        if (t == null || k == null || t.isEmpty() || k.isEmpty()) return 0;
        // 簡單計數
        return t.split(Pattern.quote(k), -1).length - 1;
    }
    private String buildFullSearchableContent(Node n) { return n.getTitle() + " " + n.getContent(); }
    private Map<String, Node> identifyParentChildRelationships(List<Node> n) {
        Map<String, Node> m = new HashMap<>();
        for (Node node : n) { node.setGameId(node.getTitle()); node.setParent(true); m.put(node.getTitle(), node); }
        return m;
    }
    private Map<String, GameRankingResult> rankGames(Map<String, Node> g) {
        return g.entrySet().stream()
            .sorted((a, b) -> Double.compare(b.getValue().getScore(), a.getValue().getScore()))
            .collect(Collectors.toMap(Map.Entry::getKey, e -> new GameRankingResult(e.getValue().getUrl(), e.getValue().getScore(), e.getValue().getTitle(), e.getValue()), (e1, e2) -> e1, LinkedHashMap::new));
    }

    // ★★★ 修復 public 權限，避免 Controller 報錯 ★★★
    public static class GameRankingResult {
        // 使用 public final 讓外部可以直接讀取 (最簡單的解法)
        public final String link; 
        public final double score; 
        public final String title; 
        public final Node node;
        
        public GameRankingResult(String link, double score, String title, Node node) { 
            this.link = link; 
            this.score = score; 
            this.title = title; 
            this.node = node; 
        }
        
        // 為了相容性保留 Getter
        public String getLink() { return link; }
        public double getScore() { return score; }
        public String getTitle() { return title; }
        public Node getNode() { return node; }
    }
}